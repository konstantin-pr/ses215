<?php
/**
 * Created by PhpStorm.
 */

define( "PHPUNIT_TESTSUITE", "true");
define( "AUTHORIZENET_API_LOGIN_ID", "");
define( "AUTHORIZENET_TRANSACTION_KEY", "");
define( "AUTHORIZENET_MD5_SETTING", "");
define( "MERCHANT_LIVE_API_LOGIN_ID", "");
define( "MERCHANT_LIVE_TRANSACTION_KEY", "");
define( "CP_API_LOGIN_ID", "");
define( "CP_TRANSACTION_KEY", "");
define( "AUTHORIZENET_LOG_FILE",  "./authorize-net.log");

?>